<?php

session_start();

unset($_SESSION["lista"]);
$_SESSION["lista"] = [];

header("Location: ./index.php?status=2");
?>