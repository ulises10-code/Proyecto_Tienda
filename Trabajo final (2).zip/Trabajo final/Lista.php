<?php include('Conexion.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGTC</title>
    <link rel="stylesheet" href="Bootstrap-5-5.0.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="Main.css">

    <link rel="stylesheet" href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js">

</head>
<body>
<div class= "conteiner">

  
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
            <a class="navbar-brand" href="perfiles.html"> <img src="logo2.png" alt="" width="30" height="24"> SGTC </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="Gerente.html">INICIO</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="empleadohome.html">EMPLEADO</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Inventario.html">INVENTARIO</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="http://localhost/trabajo final/index.php">VENTAS</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="Lista.php">REGISTROS</a>
                </li>
                </ul>
            </div>
            </div>
        </nav>
    <?php
    include_once "conexion.php";
    $sentencia = $conexion->query("SELECT ventas.total, ventas.fecha, ventas.id, GROUP_CONCAT(	inventario.codigo, '..',  inventario.Nombre, '..', 
    productos_vendidos.cantidad SEPARATOR '__') AS inventario FROM ventas INNER JOIN productos_vendidos ON productos_vendidos.id_venta = ventas.id INNER JOIN inventario 
    ON inventario.id = productos_vendidos.id_producto GROUP BY ventas.id ORDER BY ventas.id;");
    $ventas = $sentencia->fetchAll(PDO::FETCH_OBJ);
    ?>

        <div class="col-xs-12">
            <h1>Ventas</h1>
            <div>
                <a class="btn btn-success" href="./index.php">Nueva venta <i class="fa fa-plus"></i></a>
            </div>
            <br>
            <div class="row">
                <div class="col-g-8">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered" style="width:92% ">
                            <thead>
                                <tr>
                                    <th>Número</th>
                                    <th>Fecha</th>
                                    <th>Productos vendidos</th>
                                    <th>Total</th>
                                    <th>Eliminar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($ventas as $venta){ ?>
                                <tr>
                                    <td><?php echo $venta->id ?></td>
                                    <td><?php echo $venta->fecha ?></td>
                                    <td>
                                        <table class="table table-striped table-bordered" style="width:92% ">
                                            <thead>
                                                <tr>
                                                    <th>Código</th>
                                                    <th>Nombre</th>
                                                    <th>Cantidad</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach(explode("__", $venta->inventario) as $productosConcatenados){ 
                                                $producto = explode("..", $productosConcatenados)
                                                ?>
                                                <tr>
                                                    <td><?php echo $producto[0] ?></td>
                                                    <td><?php echo $producto[1] ?></td>
                                                    <td><?php echo $producto[2] ?></td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </td>
                                    <td><?php echo $venta->total ?></td>
                                    <td><a class="btn btn-danger" href="<?php echo "eliminarVenta.php?id=" . $venta->id?>"> Borrar<i class="fa fa-trash"></i></a></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php