<?php
if (!isset($_POST["codigo"])) {
    return;
}

$codigo = $_POST["codigo"];
include_once "Conexion.php";
$sentencia = $conexion->prepare("SELECT * FROM inventario WHERE codigo = ?;");
$sentencia->execute([$codigo]);
$producto = $sentencia->fetch(PDO::FETCH_OBJ);

if (!$producto) {
    header("Location: ./index2.php?status=4");
    exit;
}
# Si no hay existencia.
if ($producto->existencia < 1) {
    header("Location: ./index2.php?status=5");
    exit;
}
session_start();
# Buscar producto dentro del cartito
$indice = false;
for ($i = 0; $i < count($_SESSION["lista"]); $i++) {
    if ($_SESSION["lista"][$i]->codigo === $codigo) {
        $indice = $i;
        break;
    }
}
# Si no existe, se agrega
if ($indice === false) {
    $producto->cantidad = 1;
    $producto->total = $producto->Valor_venta;
    array_push($_SESSION["lista"], $producto);
} else {
    $cantidadExistente = $_SESSION["lista"][$indice]->cantidad;
    # si al sumarle uno supera lo que existe, no se agrega
    if ($cantidadExistente + 1 > $producto->existencia) {
        header("Location: ./index2.php?status=5");
        exit;
    }
    $_SESSION["lista"][$indice]->cantidad++;
    $_SESSION["lista"][$indice]->total = $_SESSION["lista"][$indice]->cantidad * $_SESSION["lista"][$indice]->Valor_venta;
}
header("Location: ./index2.php");
