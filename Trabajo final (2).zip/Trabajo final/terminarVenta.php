<?php
if(!isset($_POST["total"])) exit;


session_start();


$total = $_POST["total"];
include_once "conexion.php";


$ahora = date("Y-m-d H:i:s");


$sentencia = $conexion->prepare("INSERT INTO ventas(fecha, total) VALUES (?, ?);");
$sentencia->execute([$ahora, $total]);

$sentencia = $conexion->prepare("SELECT id FROM ventas ORDER BY id DESC LIMIT 1;");
$sentencia->execute();
$resultado = $sentencia->fetch(PDO::FETCH_OBJ);

$idVenta = $resultado === false ? 1 : $resultado->id;

$conexion->beginTransaction();
$sentencia = $conexion->prepare("INSERT INTO productos_vendidos(id_producto, id_venta, cantidad) VALUES (?, ?, ?);");
$sentenciaExistencia = $conexion->prepare("UPDATE inventario SET existencia = existencia - ? WHERE id = ?;");
foreach ($_SESSION["lista"] as $producto) {
	$total += $producto->total;
	$sentencia->execute([$producto->id, $idVenta, $producto->cantidad]);
	$sentenciaExistencia->execute([$producto->cantidad, $producto->id]);
}
$conexion->commit();
unset($_SESSION["lista"]);
$_SESSION["lista"] = [];
header("Location: ./index.php?status=1");
?>