<?php include('Conexion.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGTC</title>
    <link rel="stylesheet" href="Bootstrap-5-5.0.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="Main.css">

    <link rel="stylesheet" href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js">

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
          <a class="navbar-brand" href="perfiles.html"> <img src="logo2.png" alt="" width="30" height="24"> SGTC </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="Cajero.html">INICIO</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="http://localhost/trabajo final/index2.php">VENTAS</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>

     <?php 
    session_start();
    if(!isset($_SESSION["lista"])) $_SESSION["lista"] = [];
    $granTotal = 0;
    ?>
        <?php
			if(isset($_GET["status"])){
				if($_GET["status"] === "1"){
					?>
						<div class="alert alert-success">
							<strong>¡Correcto!</strong> Venta realizada correctamente
						</div>
					<?php
				}
                else if($_GET["status"] === "2"){
					?>
					<div class="alert alert-info">
							<strong>Venta cancelada</strong>
						</div>
					<?php
				}
                else if($_GET["status"] === "3"){
					?>
					<div class="alert alert-info">
							<strong>Ok</strong> Producto quitado de la lista
						</div>
					<?php
				}
                else if($_GET["status"] === "4"){
					?>
					<div class="alert alert-warning">
							<strong>Error:</strong> El producto que buscas no existe
						</div>
					<?php
				}
                else if($_GET["status"] === "5"){
					?>
					<div class="alert alert-danger">
							<strong>Error: </strong>El producto está agotado
						</div>
					<?php
				}
                else{
					?>
					<div class="alert alert-danger">
							<strong>Error:</strong> Algo salió mal mientras se realizaba la venta
						</div>
					<?php
				}
			}
    ?>
        <p>
            Busqueda de producto
        </p>
        <div class="row">  
            <div class="col-2" style="margin-left: 1rem;">
                <form method="post" action="agregarALista2.php" >
                    <label for="codigo">Código de barras:</label>
                    <input autocomplete="off" autofocus class="form-control" name="codigo" required type="text" id="codigo" 
                    placeholder="Inserta el código">
                </form> 
            </div>  
        </div>
        <p>
            Lista de productos
        </p>
    <div class="conteiner">
        <div class="row">
            <div class="col-g-8">
                <div class="table-responsive">
                    <table id="productos" class="table table-striped table-bordered" style="width:92% ">
                        <thead>
                            <tr>
                                <th>Codigo</th>
                                <th>Nombre</th> 
                                <th>Precio de venta</td> 
                                <th>cantidad</th> 
                                <th>Precio total</th> 
                                <th>Borrar</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($_SESSION["lista"] as $indice => $producto){ 
                            $granTotal += $producto->total;
                            ?>
                            <tr>
                                <td><?php echo $producto->codigo?></td>
                                <td><?php echo $producto->Nombre?></td>
                                <td><?php echo $producto->Valor_venta?></td>
                                <td><?php echo $producto->cantidad?></td>
                                <td><?php echo $producto->total?></td>
                                <td><a class="btn btn-success" href="<?php echo "quitarDeLista2.php?indice=" . $indice?>">borrar</a></td>
                            </tr>
                        <?php } ?>
                        </tbody>
                    </table>
                    <h3>Total: <?php echo $granTotal; ?></h3>
                </div>
            </div>
        </div>
    </div>
    <p>
        Pago 
    </p>
    <script>
        function resta(){
            var total = <?php echo $granTotal; ?>;
            var pago = parseFloat(document.getElementById('Pago').value);
            document.getElementById('cambio').innerHTML= pago - total; 
        } 
    </script>
    <div class="row">  
        <div class="col-2" style="margin-left: 1rem;">
            <form method="post" >
                <label for="Pago">Pago:</label>
                <input autocomplete="off" autofocus class="form-control" required type="text" id="Pago" 
                placeholder="cantidad de pago"><br>
            </form> 
        </div> 
        <div class="col-3" style="margin-top: 1.4rem;">
        <button class="btn btn-success" type= "button" onclick= "resta()">Realizar compra</button>
        </div>   
    </div>
    <div class="row">
        <div class= "col-4">
	       <h4>Su cambio es: $<samp id="cambio"></samp></h4> 
        </div>
    </div>
    <form action="./terminarVenta.php" method="POST">
			<input name="total" type="hidden" value="<?php echo $granTotal;?>">
			<button type="submit" class="btn btn-success">Terminar venta</button>
			<a href="./cancelarVenta2.php" class="btn btn-danger">Cancelar venta</a>
		</form>
    
</body>
</html>
<?php

