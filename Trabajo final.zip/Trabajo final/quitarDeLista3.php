<?php
if(!isset($_GET["indice"])) return;
$indice = $_GET["indice"];

session_start();
array_splice($_SESSION["lista"], $indice, 1);
header("Location: ./index3.php?status=3");
?>