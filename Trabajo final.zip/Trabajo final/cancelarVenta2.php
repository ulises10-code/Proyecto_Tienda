<?php

session_start();

unset($_SESSION["lista"]);
$_SESSION["lista"] = [];

header("Location: ./index2.php?status=2");
?>